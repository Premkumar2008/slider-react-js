import React, {useState} from 'react';

import './App.css';

const App = () => {
//set default active element (i.e 2)
const [activeClass, setActiveClass] = useState({
    title: '2',
    value: "molecular",
	bgColor: "linear-gradient(to bottom left, #4eabd6, #3b9f6d)",
	activeImg: "molecular40.svg",
		textData: "Simply dummy text of Lorem Impusum has been the standard Impusum has been the standard -2",
	textColor: "two"
  });
 //list of obj elements total 3
const [array, setArray] = useState([
  {
    title: '1',
    value: "file",
	bgColor: "linear-gradient(to bottom left, #21bdce, #0976b3)",
	activeImg: "file40.svg",
	textData: "Lorem Impusum has been the standard -1 Simply dummy text of the printing and typesetting industry. ",
	textColor: "one"
  },
  {
    title: '2',
    value: "molecular",
	bgColor: "linear-gradient(to bottom left, #4eabd6 , #3b9f6d)",
	activeImg: "molecular40.svg",
	textData: "Simply dummy text of Lorem Impusum has been the standard Impusum has been the standard -2",
	textColor: "two"
  },
  {
    title: '3',
    value: "brain",
	bgColor: "linear-gradient(to bottom left, #731d95 0%, #2f3f9b 100%)",
	activeImg: "brain40.svg",
	textData: "Simply dummy text of the printing and typesetting industry. Lorem Impusum has been the standard -3",
	textColor: "three"
  },
  // {
  //   title: '4',
  //   value: 4
  // },
  // {
  //   title: '5',
  //   value: 5
  // }
]);
//action starts when click lists
  const clickbutton = (obj) => {
    setActiveClass(obj);
   // console.log("title::::", obj);
   
   //set middle index as 1 default since we have 3 elements [0,1,2] it will work for any odd numbers and can make dynamic
    const mIndex =  1;
	//find clicked element index to set center index element.
    const cIndex = array.findIndex(a => a.title === obj.title);
   // console.log("cIndex::::", cIndex);
    let newArray = [...array]
	//find array length
    const arrayLength = array.length - 1
	//console.log("arraylength::::", arrayLength);
	
	//checks center index is not equal to middle index if true below code will excecutes 
    if(cIndex !== mIndex) {
	//checks center index is less than middle index to find which direction array need to move 
      if(cIndex < mIndex) {
	//diff is used to find how many index we need to move to reach center
        const diff = mIndex - cIndex;
        for (let i =0; i<=arrayLength; i++) {
          if ((i + diff) <= (arrayLength)) {
            console.log("newIndex-1:::", i + diff, array[i]);
			//array value updated with newarray[]
            newArray[i + diff] = array[i];
          }
          if(((i + diff) > (arrayLength))) {
            const newDiff = (i + diff) - arrayLength
            newArray[(newDiff === mIndex || i === arrayLength )? 0 : newDiff] = array[i];
            console.log("newIndex-2:::::", newDiff === mIndex ? 0 : newDiff, array[i]);
          }
        }
      } else {
		  //enters if center index is greater than middle index
        const diff = mIndex - cIndex;
		console.log("diffffffffffff-1:::", diff);
        for (let i =0; i<=arrayLength; i++) {
          if ((i - (diff)) <= (mIndex)) {
            newArray[( (i + (diff)) === mIndex || (i + (diff)) < 0 ) ? arrayLength : (i + (diff))] = array[i];
            console.log("BigIndex:::2",(i + (diff)) === mIndex ? arrayLength : (i + (diff)), array[i]);
          }
          else {
            console.log("BigIndex:::2", (i + diff), array[i]);
            newArray[i + diff] = array[i];
          }
        }
      }
    }
    console.log("newArray:::",newArray)
    
	setArray([...newArray]);
	 
	
  }
 
 
 
  return (
    <div className="">
      <title>Home</title>
      <body class="primary-bg-color">
      <div class="slider-container-bg">
        <div class="inner-container">
        <div class="slider-box">
		<>
		 <div className={`slider-title ${activeClass.textColor}`}>Louremipusum</div>
          <div class="slider-desc">
		  {activeClass.textData}
          </div>
		  </>
      </div>
    <div class="slider-indicator">
      <ul>
	  <li class="dots small">
	  <div class="dot-sec-small"></div>
	  </li>
	  <li class="dots"><div class="dot-sec"></div></li>
        {
          array.map((eachArray, i) => (
		  
            <li className={"img " + (i === 1 ? 'active' : '')} style={{ background: i === 1 ? activeClass.bgColor : '#1b1b1b' , height: i === 1 ?"55px": "25px",width: i === 1 ?"55px" : "25px", marginTop: i === 1 ? "0px" : "15px" }} >
              <div class="indi-1" onClick={() => {clickbutton(eachArray)}}>
				  
			  <img className="sdeimg" src = {eachArray.value + '.svg'}  height="22px" alt=""/>
				  
			   <img className={"crntimg "} src = {eachArray.activeImg }  height="35px" alt=""/>
			   
				  
			  </div>
            </li>
          ))
        } 
 <li class="dots rgt"><div class="dot-sec"></div></li>	
<li class="dots small">
	  <div class="dot-sec-small"></div>
	  </li> 
      </ul>
    </div>
  </div>
  </div>
</body>
    </div>
  );
}

export default App;
